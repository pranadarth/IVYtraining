using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace OnlineShopping.Pages
{
    public class DeleteProdAdminModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
